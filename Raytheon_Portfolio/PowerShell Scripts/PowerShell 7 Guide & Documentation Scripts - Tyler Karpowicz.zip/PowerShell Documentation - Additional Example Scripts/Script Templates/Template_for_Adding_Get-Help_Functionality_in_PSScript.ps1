<#
    .SYNOPSIS
    <A brief description about the functionality of the PowerShell Script.>

    .DESCRIPTION
    <A detailed description about the functionality of the PowerShell Script.>

    .INPUTS
    [<The acceptable input object types for the PowerShell Script.>] 

    .OUTPUTS
    System.<The resulting output object types for the PowerShell Script.>

    .EXAMPLE
    C:\PS> .\<Name of PowerShell Script>.ps1
    <Example Prompt (if applicable)>
    <Example Output (if applicable)>
#>

<#
##-----Script Code-----##
#>